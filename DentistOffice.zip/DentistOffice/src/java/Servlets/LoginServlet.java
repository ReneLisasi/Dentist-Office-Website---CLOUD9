/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import BusinessObjects.Patient;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author renel
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            //get custid & custpw
            Patient up1 = new Patient();
            
            //main code*****************************
            String id, pw, dbId, dbPw;
            id = request.getParameter("patIdTb");
            pw = request.getParameter("patPwTb");
            up1.selectDB(id);
            dbId = up1.getPatId();
            dbPw = up1.getPasswd();
            //valid login
           System.out.println("ID " + id + " PW: " + pw);
            /*use booleans in step 4 (decision) because skipping steps results in nullPointer
            exception for ud1 object in the jsp
            */
            boolean y= false;
            //Step 4
            if(pw.equals(dbPw) && id.equals(dbId)){
                y = true;
                System.out.println("y = true");
            } 
            //invalid login
            else{
                y=false;
                System.out.println("y = false");
            } 

            //Step 5 Put object in session
            HttpSession ses1;
            ses1 = request.getSession();
            ses1.setAttribute("up1", up1);
            System.out.println("Dentist added to Session/scheduling login.jsp");
            //Step 6
            if (y == true){
                RequestDispatcher rd = request.getRequestDispatcher("/Patient/Home.jsp");
                rd.forward(request, response);
                System.out.println("RequestDispatch Valid login");
            }
            else{
                RequestDispatcher rd = request.getRequestDispatcher("/Patient/Login.jsp");
                rd.forward(request, response);
                System.out.println("RequestDispatch invalid login");
            }
        } catch (IOException ex) {
            Logger.getLogger(DentistLoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }/*
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet LoginServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");*/
        }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
