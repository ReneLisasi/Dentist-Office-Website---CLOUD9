/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import BusinessObjects.Patient;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author renel
 */
@WebServlet(name = "PatientServlet", urlPatterns = {"/PatientServlet"})
public class PatientServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String value= request.getParameter("button");
            String updateProfile= "updateProfile";
            String id = request.getParameter("patIdTb");
            String status= "Update successful";
            //Create object
            Patient p1=new Patient();
            
            //update profile
            if (value.equals(updateProfile)){
                Patient up1= new Patient();
                up1.selectDB(id);
                up1.setPatId(request.getParameter("patIdTb"));
                up1.setPasswd(request.getParameter("patPwTb"));
                up1.setFirstName(request.getParameter("patFirstNameTb"));
                up1.setLastName(request.getParameter("patLastNameTb"));
                up1.setAddress(request.getParameter("patAddressTb"));
                up1.setEmail(request.getParameter("patEmailTb"));
                up1.setInsCo(request.getParameter("patInsCoTb"));
                up1.updateDB();
                 //Step #5 - Put Student Object in Session using HttpSession
                HttpSession ses1;
                ses1 = request.getSession();
                ses1.setAttribute("status", status);
                ses1.setAttribute("up1", up1);
                System.out.println("Update sending x to jsp");
               //Step 6
               RequestDispatcher rd = request.getRequestDispatcher("/Patient/Profile.jsp");
                rd.forward(request, response);
                System.out.println("RequestDispatch Valid login");
             
            }
            /*out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet PatientServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet PatientServlet at " + up1.getPasswd() + "</h1>");
            out.println("</body>");
            out.println("</html>");*/
           
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
