/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessObjects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author renel
 */
public class Appointment {
    //properties
    String apptDate;
    String patId;
    String dentId;
    String procCode;
    
    //array to store schedule objects
        public static ArrayList<Appointment> appointmentList = new ArrayList<>();
        //array to store how many records are in the schedule
        public static List rowValues = new ArrayList();
        //property to store raw database count
        private static int rawAppointmentDBCount;
    //Constructor that passes no arguments
    
    public Appointment(){
        apptDate = patId =dentId = procCode= null;
    }
    
    public Appointment(String apptDate, String patId, String dentId, String procCode){
        this.apptDate = apptDate;
        this.patId = patId;
        this.dentId = dentId;
        this.procCode = procCode;
    }
    
    //main
    public static void main(String[]args){
        Appointment a1 = new Appointment();
        a1.selectDB("A900");
        //a1.deleteDB();
        //a1.insertDB("2021-05-04T09:25", "A911", "D201", "P122");
        a1.setDentId("D202");
        a1.updateDB();
        a1.display();
    }

    /**
     * Method that selects appointments from the database
     */
    public void selectDB(String i) {
        patId=i;
        try{
            Class.forName(Strings.driver);
            Connection con = DriverManager.getConnection(Strings.url);
            
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from Appointments where patId='"+i+"'");
            
            rs.next();
            //patId = rs.getString(1);
            dentId = rs.getString("dentId");
            procCode = rs.getString("procCode");
            apptDate = rs.getString("apptDateTime");
            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
    /**
     * Method that inserts appointments into the database
     */
    public void insertDB(String apptDate,String patId,String dentId,String procCode){
         
        //assign values
        this.apptDate = apptDate;
        this.patId = patId;
        this.dentId= dentId;
        this.procCode = procCode;
        
        try{
            Class.forName(Strings.driver);
            Connection c1 = DriverManager.getConnection(Strings.url);

            //Create StAtement
            java.sql.Statement stmt = c1.createStatement();
            //update stAtement definition
            String sql2 = "insert into Appointments(apptDateTime,patId,dentId,procCode) values('"+getApptDate()+"',"+
                                                        "'"+getPatId()+"',"+
                                                      "'"+getDentId()+"',"+ 
                                                        "'"+getProcCode()+"'"+
                                                        ")"; 
            //print the stAtement
            System.out.println(sql2);
            //check for duplicates
            int n1 = stmt.executeUpdate(sql2);
            if (n1==1)
                System.out.println("INSERT Successful!!!");
            else
                System.out.println("INSERT FAILED***********");
            c1.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
    }
    /**
     * Method that deletes appointments from the database
     */
        public void deleteDB() {
         try{
            Class.forName(Strings.driver);
            Connection con = DriverManager.getConnection(Strings.url);
            
            Statement stmt = con.createStatement();
            String sql = "Delete from Appointments where patid='"+getPatId()+"'";
            System.out.println(sql);
            int n = stmt.executeUpdate(sql);
            if (n==1)
                System.out.println("DELETE Successful!!!");
            else
                System.out.println("DELETE FAILED***********");
            con.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
    }
    
/**
     * Method that updates appointments from the database
     */
    public void updateDB() {
        try{
            Class.forName(Strings.driver);    
            Connection con4 = DriverManager.getConnection(Strings.url);  
            System.out.println("Database Connected");
            Statement stmt = con4.createStatement();

            String sql4 = "Update Appointments set apptDateTime = '"+getApptDate()+"',"+
                                                //"patId = '"+getPatId()+"',"+
                                                "dentId= '" +getDentId() + "',"+
                                                "procCode = '" +getProcCode() +"'"+
                                                "Where patId ='"+getPatId()+"'";
            System.out.println(sql4);
            System.out.println("Data set");
            int n = stmt.executeUpdate(sql4);
            if(n==1)
                System.out.println("UPDATE Successful!!!");
            else
                System.out.println("UPDATE Failed************");
            con4.close();
            }
            catch(Exception e1){
                System.out.println(e1);
            }
    }
    
    /**
     * Method that selects all appointments from the database
     */
    public static ArrayList<Appointment> getAllAppointments() throws ClassNotFoundException, SQLException {
        try {
//Load DB Driver
            Class.forName(Strings.driver);
            Connection c1 = DriverManager.getConnection(Strings.url);

            //Execute SQL StAtement
            Statement stmt = c1.createStatement();
            ResultSet rst = stmt.executeQuery("Select * From Appointments");
            System.out.println("Executing get all schedlues query");
            //Process ResultSet

            while (rst.next()) {
                Appointment aa1 = new Appointment(
                        rst.getString("apptDateTime"),
                        rst.getString("patId"),
                        rst.getString("dentId"),
                        rst.getString("procCode"));

                appointmentList.add(aa1);
            }

        } catch (Exception se) {
            System.out.println(se);
        }
        return appointmentList;
    }
    /**
     * Method that counts the number of appointments from the database
     */

    public static int getAppointmentCount() {
        try {
            //Load DB Driver
            Class.forName(Strings.driver);
            Connection c1 = DriverManager.getConnection(Strings.url);

            //Execute SQL StAtement
            Statement stmt = c1.createStatement();
            ResultSet rs = stmt.executeQuery("Select count(*) From Appointments");
            System.out.println("Executing Query to get schedule count");
            //Process ResultSet

            rs.next();
            rawAppointmentDBCount = rs.getInt(1);
            System.out.println(rawAppointmentDBCount);

            c1.close();
        } catch (Exception se) {
            System.out.println(se);
        }
        return rawAppointmentDBCount;
    }
    
    //End DB
    
    /**
     * Method that displays to the console
     */
    public void display(){
        System.out.println("Date: "+apptDate+" patId: "+patId+" dentId: "+dentId+ " procCode: "+ procCode);
    }
    
    //getters and setters
    public String getApptDate() {return apptDate;}
    public void setApptDate(String apptDate) {this.apptDate = apptDate;}
    public String getPatId() {return patId;}
    public void setPatId(String patId) {this.patId = patId;}
    public String getDentId() {return dentId;}
    public void setDentId(String dentId) {this.dentId = dentId;}
    public String getProcCode() {return procCode;}
    public void setProcCode(String procCode) {this.procCode = procCode;}   


}
