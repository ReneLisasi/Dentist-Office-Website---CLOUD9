/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessObjects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author renel
 * 
 */
public class Procedure {
    //properties
    String procCode;
    String procName;
    String procDesc;
    double cost;
    //array to store procedure objects
        public static ArrayList<Procedure> procedureList = new ArrayList<>();
        //array to store how many records are in the procedure
        public static List rowValues = new ArrayList();
        //property to store raw database count
        private static int rawProcedureDBCount;
    
    //Constructor that takes none
    public Procedure(){
    procCode=
    procName=
    procDesc=null;
    cost = 0;
    }
 
    //Constructor that takes all
    public Procedure(String procCode, String procName, String procDesc, Double cost) {
        this.procCode = procCode;
        this.procName = procName;
        this.procDesc = procDesc;
        this.cost = cost;
    }
    //main
    public static void main(String[]args){
        Procedure p1= new Procedure();
        p1.selectDB("P114");
        p1.display();
    }
    //Start DB********************************************************************
    /**
     * Method that selects a procedure from the database
     */
    public void selectDB(String i){
        procCode=i;
        try{
            Class.forName(Strings.driver);
            Connection con = DriverManager.getConnection(Strings.url);
            
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from Procedures where procCode='"+i+"'");
            
            rs.next();
            procName = rs.getString("procName");
            procDesc = rs.getString("procDesc");
            cost = rs.getDouble("cost");
            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    /**
     * Method that selects all procedures from the database
     */
    public static ArrayList<Procedure> getAllProcedures() throws ClassNotFoundException, SQLException {
        try {
//Load DB Driver
            Class.forName(Strings.driver);
            Connection c1 = DriverManager.getConnection(Strings.url);

            //Execute SQL StAtement
            Statement stmt = c1.createStatement();
            ResultSet rst = stmt.executeQuery("Select * From Procedures");
            System.out.println("Executing get all schedlues query");
            //Process ResultSet

            while (rst.next()) {
                Procedure aa1 = new Procedure(
                        rst.getString("procCode"),
                        rst.getString("procName"),
                        rst.getString("procDesc"),
                        rst.getDouble("cost"));

                procedureList.add(aa1);
            }

        } catch (Exception se) {
            System.out.println(se);
        }
        return procedureList;
    }
 /**
     * Method that counts all procedure from the database
     * and supplements getAllProcedures method
     */
    public static int getProcedureCount() {
        try {
            //Load DB Driver
            Class.forName(Strings.driver);
            Connection c1 = DriverManager.getConnection(Strings.url);

            //Execute SQL StAtement
            Statement stmt = c1.createStatement();
            ResultSet rs = stmt.executeQuery("Select count(*) From Procedures");
            System.out.println("Executing Query to get schedule count");
            //Process ResultSet

            rs.next();
            rawProcedureDBCount = rs.getInt(1);
            System.out.println(rawProcedureDBCount);

            c1.close();
        } catch (Exception se) {
            System.out.println(se);
        }
        return rawProcedureDBCount;
    }
    
    //End DB
    
    //display
    public void display(){
        System.out.println("Object1: "+ procCode+ " Object2: "+procName+" Object3: "+ procDesc+ " Object4: "+cost);
    }
    
    public String getProcCode() {
        return procCode;
    }

    public void setProcCode(String procCode) {
        this.procCode = procCode;
    }

    public String getProcName() {
        return procName;
    }

    public void setProcName(String procName) {
        this.procName = procName;
    }

    public String getProcDesc() {
        return procDesc;
    }

    public void setProcDesc(String procDesc) {
        this.procDesc = procDesc;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }
    
    
    
}
