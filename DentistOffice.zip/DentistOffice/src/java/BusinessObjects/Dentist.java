/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessObjects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author renel
 */
public class Dentist {
    //properties
    String id;
    String passwd;
    String firstName;
    String lastName;
    String email;
    String office;
        //array to store procedure objects
        public static ArrayList<Dentist> dentistList = new ArrayList<>();
        //array to store how many records are in the procedure
        public static List rowValues = new ArrayList();
        //property to store raw database count
        private static int rawDentistDBCount;
    //Constructor that takes no arguments
    public Dentist(){
        id= passwd = firstName = lastName = email = office = null;
    }
    

    
    //constructor that takes all arguments
    public Dentist(String id, String passwd, String firstName, String lastName, String email, String office) {
        this.id = id;
        this.passwd = passwd;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.office = office;
    }
    
    //main
    public static void main(String[]args){
        Dentist d1= new Dentist();
        d1.selectDB("D201");
        d1.setPasswd("ocean");
        d1.updateDB();
        d1.display();
    }
    
     /**
     * Method that selects a dentist from the database
     */
    public void selectDB(String i) {
        id = i;
        try {
            Class.forName(Strings.driver);
            Connection conn = DriverManager.getConnection(Strings.url);

            Statement stmt = conn.createStatement();
            ResultSet rs;
            String sql = ("Select * From Dentists Where id = '" + i + "'");
//            System.out.println(sql);

            rs = stmt.executeQuery(sql);

            //Process ResultSet
            // while (rs.next()) {
            rs.next();
            //adminId = rs.getString(0);
            this.passwd = rs.getString("passwd");
            this.firstName= rs.getString("firstname");
            this.lastName = rs.getString("lastname");
            this.email = rs.getString("email");
            this.office = rs.getString("office");

            //}  
            conn.close();

        } catch (ClassNotFoundException | SQLException se) {
            System.out.println(se);

        }
    }//End SelectDB

 /**
     * Method that updates a dentist from the database
     */
        public void updateDB(){
             try {
            Class.forName(Strings.driver);
            Connection con1 = DriverManager.getConnection(Strings.url);

            Statement stmt = con1.createStatement();
            String sql = "update Dentists set passwd = '" + getPasswd() + "',"
                    + " firstname ='" + getFirstName() + "',"
                    + " lastname ='" + getLastName() + "',"
                    + " email ='" + getEmail() + "',"
                    + " office = '" + getOffice() + "'"
                    + " where Id='" + getId() + "'";
            System.out.println(sql);
            int n = stmt.executeUpdate(sql);
            if (n == 1) {
                System.out.println("UPDATE Successful!!!");
            } else {
                System.out.println("UPDATE FAILED***********");
            }
            con1.close();
        } catch (Exception e1) {
            System.out.println(e1);
        }

    }
        
        /**
     * Method that selects all dentists from the database, mainly used for jsp presentation
     */
    public static ArrayList<Dentist> getAllDentists() throws ClassNotFoundException, SQLException {
        try {
//Load DB Driver
            Class.forName(Strings.driver);
            Connection c1 = DriverManager.getConnection(Strings.url);

            //Execute SQL StAtement
            Statement stmt = c1.createStatement();
            ResultSet rst = stmt.executeQuery("Select * From Dentists");
            System.out.println("Executing get all schedlues query");
            //Process ResultSet

            while (rst.next()) {
                Dentist aa1 = new Dentist(
                        rst.getString("id"),
                        rst.getString("passwd"),
                        rst.getString("firstname"),
                        rst.getString("lastName"),
                        rst.getString("email"),
                        rst.getString("office"));

                dentistList.add(aa1);
            }

        } catch (Exception se) {
            System.out.println(se);
        }
        return dentistList;
    }
 /**
     * Method that counts all dentists from the database 
     * and supplements getAllDentists
     */
    public static int getDentistCount() {
        try {
            //Load DB Driver
            Class.forName(Strings.driver);
            Connection c1 = DriverManager.getConnection(Strings.url);

            //Execute SQL StAtement
            Statement stmt = c1.createStatement();
            ResultSet rs = stmt.executeQuery("Select count(*) From Procedures");
            System.out.println("Executing Query to get schedule count");
            //Process ResultSet

            rs.next();
            rawDentistDBCount = rs.getInt(1);
            System.out.println(rawDentistDBCount);

            c1.close();
        } catch (Exception se) {
            System.out.println(se);
        }
        return rawDentistDBCount;
    }

    //end db***********************
    
    public String getId() {return id;}
    public void setId(String id) {this.id = id;}
    public String getPasswd() {return passwd;}
    public void setPasswd(String passwd) {this.passwd = passwd;}
    public String getFirstName() {return firstName;}
    public void setFirstName(String firstName) {this.firstName = firstName;}
    public String getLastName() {return lastName;}
    public void setLastName(String lastName) {this.lastName = lastName;}
    public String getEmail() {return email;}
    public void setEmail(String email) {this.email = email;}
    public String getOffice() {return office;}
    public void setOffice(String office) {this.office = office;}

    private void display() {
         System.out.println("Id "+id+" Password: "+passwd+" fname: "+firstName+" lastName: "+lastName+" email: "+ email +" office:"+office);
    }
    
    
}
