/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessObjects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author renel
 */
public class Patient {
    //properties
    String patId;
    String passwd;
    String firstName;
    String lastName;
    String address;
    String email;
    String insCo;

    public Patient(){
    patId=
    passwd=
    firstName=
    lastName=
    address=
    email=
    insCo=null;
    }
    
    public Patient(String patId, String passwd, String firstName, String lastName, String address, String email, String insCo) {
        this.patId = patId;
        this.passwd = passwd;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.email = email;
        this.insCo = insCo;
    }
    
    //main
    public static void main (String[]args){
    Patient p1=new Patient();
    p1.selectDB("A900");
    p1.setPasswd("1111");
    p1.updateDB();
    p1.display();
}
 /**
     * Method that updates a patient from the database
     */
        public void updateDB(){
             try {
            Class.forName(Strings.driver);
            Connection con1 = DriverManager.getConnection(Strings.url);

            Statement stmt = con1.createStatement();
            String sql = "update Patients set passwd= '" + getPasswd() + "',"
                    + " firstname ='" + getFirstName() + "',"
                    + " addr ='" + getAddress() + "',"
                    + " email ='" + getEmail() + "',"
                    + " insCo = '" + getInsCo() + "'"
                    + " where patId='" + getPatId() + "'";
            System.out.println(sql);
            int n = stmt.executeUpdate(sql);
            if (n == 1) {
                System.out.println("UPDATE Successful!!!");
            } else {
                System.out.println("UPDATE FAILED***********");
            }
            con1.close();
        } catch (Exception e1) {
            System.out.println(e1);
        }

    }
    /**
     * Method that selects a patient from the database
     */
    public void selectDB(String i) {
        patId = i;
        try {    //Load DB Driver
            Class.forName(Strings.driver);
            Connection c1 = DriverManager.getConnection(Strings.url);

            //Execute SQL StAtement
            Statement stmt = c1.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from Patients where patId='" + i+"'");
            System.out.println("executingquery");
            //Process ResultSet
            rs.next();
            //Data:
            passwd = rs.getString("passwd");
            //Info:
            firstName = rs.getString(1);
            lastName = rs.getString(2);
            address = rs.getString(3);
            email = rs.getString(4);
            insCo = rs.getString(5);

            c1.close();
        } catch (Exception se) {
            System.out.println(se);
        }
    } //end selectDB() 

/**
     * Method that inserts a patient into the database
     */
        public void insertDB(String id, String pw, String fn, String ln, String adr, 
                String eml, String ins){
        //assign values
        patId=id;
        passwd=pw;
        
        try{
            Class.forName(Strings.driver);
            Connection c1 = DriverManager.getConnection(Strings.url);

            System.out.println("Betabase connected"); 
            // Create StAtement
            java.sql.Statement stmt = c1.createStatement();
            // Update stAtement definition
            String sql2 = "insert into Patients (patId,passwd,firstName,lastName,email,insCo)"
                    + " values('"
                    + getPatId() + "',"
                    + "'" + getPasswd() + "',"
                    + "'" + getFirstName() + "',"
                    + "'" + getLastName() + "',"
                    + "'" + getAddress() + "',"
                    + "'" + getEmail() + "',"
                    + "'" + getInsCo() + "'"
                    + ")";
            // Print the statement
            System.out.println(sql2);
            // Check for duplicates
            int n1 = stmt.executeUpdate(sql2);
            if (n1==1)
                System.out.println("INSERT Successful!!!");
            else
                System.out.println("INSERT FAILED***********");
            c1.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
    }/**
     * Method that deletes a patient from the database
     */
        public void deleteDB(){
            try {
            Class.forName(Strings.driver);
            java.sql.Connection con3 = DriverManager.getConnection(Strings.url);
            System.out.println("Database connected");
            //Create StAtement - Step #3
            java.sql.Statement stmt = con3.createStatement();

            //Execute StAtement - Step #4
            String sql3 = "Delete from Patients where patId ='" + getPatId() + "'";
            //Print sql stAtement
            System.out.println(sql3);
            //check for duplicates
            int n1 = stmt.executeUpdate(sql3);
            if (n1 == 1) {
                System.out.println("DELETE Successful!!!");
            } else {
                System.out.println("DELETE FAILED***********");
            }
            con3.close();
        } catch (Exception e1) {
            System.out.println(e1);
        }
}
    //end db*******************************
    //display
    public void display(){
        System.out.println("Object1: "+ patId+ " Object2: "+passwd+" Object3: "+ firstName+ " Object4: "+lastName+" Object5: "+ address+ " Object6: "+email+" Object7: "+ insCo);
    }

    public String getPatId() {
        return patId;
    }

    public void setPatId(String patId) {
        this.patId = patId;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getInsCo() {
        return insCo;
    }

    public void setInsCo(String insCo) {
        this.insCo = insCo;
    }
    
    
    
}
